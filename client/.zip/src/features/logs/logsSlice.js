import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../services/api';

export const fetchLogs = createAsyncThunk('logs/fetchLogs', async (filters, thunkAPI) => {
  try {
    const response = await api.get('/logs', { params: filters });
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message || error.message || error.toString();
    return thunkAPI.rejectWithValue(message);
  }
});

export const fetchLogStats = createAsyncThunk('logs/fetchStats', async (_, thunkAPI) => {
  try {
    const response = await api.get('/logs/stats');
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message || error.message || error.toString();
    return thunkAPI.rejectWithValue(message);
  }
});

const logsSlice = createSlice({
  name: 'logs',
  initialState: {
    logs: [],
    stats: {},
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchLogs.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchLogs.fulfilled, (state, action) => {
        state.loading = false;
        state.logs = action.payload;
      })
      .addCase(fetchLogs.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchLogStats.fulfilled, (state, action) => {
        state.stats = action.payload;
      });
  },
});

export default logsSlice.reducer;
