import React, { useState } from 'react';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import { User, Shield, Bell, Database, Globe, FileText, Activity } from 'lucide-react';
import { useSelector } from 'react-redux';

const Settings = () => {
    const [activeTab, setActiveTab] = useState('profile');
    const { user } = useSelector(state => state.auth);

    const menu = [
        { id: 'profile', label: 'Company Profile', icon: User },
        { id: 'users', label: 'Users & Permissions', icon: Shield },
        { id: 'notifications', label: 'Notifications', icon: Bell },
        { id: 'units', label: 'Units & Currencies', icon: Database },
        { id: 'docs', label: 'Templates', icon: FileText },
        { id: 'audit', label: 'Audit Logs', icon: Activity },
    ];

    return (
        <div>
            <PageHeader 
                title="System Configuration" 
                subtitle="Global workspace parameters, user governance, and regional localizations"
            />

            <div className="flex flex-col lg:flex-row gap-8">
                {/* Sidebar Navigation */}
                <aside className="w-full lg:w-64 space-y-1">
                    {menu.map((item) => (
                        <button
                            key={item.id}
                            onClick={() => setActiveTab(item.id)}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === item.id ? 'bg-black text-white shadow-lg shadow-black/10' : 'text-gray-500 hover:bg-white hover:text-black'}`}
                        >
                            <item.icon className="w-4 h-4" />
                            {item.label}
                        </button>
                    ))}
                </aside>

                {/* Main Pane */}
                <div className="flex-1 space-y-6">
                    {activeTab === 'profile' && (
                        <Card title="Corporate Identity" subtitle="Primary organizational data for documents & invoices">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">Organization Name</label>
                                    <input value="TimberERP Solutions Ltd." readOnly className="w-full bg-gray-100 border border-gray-200 rounded-lg px-4 py-2.5 text-sm font-semibold text-gray-900 outline-none" />
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">Industry Sector</label>
                                    <input value="Lumber & Wood Processing" readOnly className="w-full bg-gray-100 border border-gray-200 rounded-lg px-4 py-2.5 text-sm font-semibold text-gray-900 outline-none" />
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">Registry Identifier (TIN)</label>
                                    <input value="UK-554228911-TX" readOnly className="w-full bg-gray-100 border border-gray-200 rounded-lg px-4 py-2.5 text-sm font-semibold text-gray-900 outline-none" />
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">FSC Certification Number</label>
                                    <input value="FSC-C123456" readOnly className="w-full bg-gray-100 border border-gray-200 rounded-lg px-4 py-2.5 text-sm font-semibold text-gray-900 outline-none" />
                                </div>
                                <div className="md:col-span-2 space-y-1.5">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">Operational Headquarters</label>
                                    <textarea readOnly className="w-full bg-gray-100 border border-gray-200 rounded-lg px-4 py-2.5 text-sm font-semibold text-gray-900 outline-none h-20 resize-none">12-14 Industrial Avenue, Manchester, M17 1PT, United Kingdom</textarea>
                                </div>
                            </div>
                            <div className="mt-8 pt-6 border-t border-gray-100 flex justify-end">
                                <button className="px-6 py-2 bg-gray-100 text-gray-500 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-black hover:text-white transition-all">Request Identity Update</button>
                            </div>
                        </Card>
                    )}

                    {activeTab === 'users' && (
                        <Card title="Governance & Access" subtitle="Manage registered team members and RBAC settings">
                           <div className="mt-4 space-y-3">
                                <div className="p-4 bg-gray-50 border border-gray-100 rounded-xl flex items-center justify-between">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center text-white font-bold text-xs">A</div>
                                        <div>
                                            <p className="text-sm font-bold text-gray-900">{user?.name || 'Admin User'}</p>
                                            <p className="text-[11px] text-gray-400 font-bold uppercase tracking-tighter">{user?.email || 'admin@timberERP.com'}</p>
                                        </div>
                                    </div>
                                    <Badge status="active">System Root</Badge>
                                </div>
                           </div>
                           <p className="mt-10 py-10 text-center text-gray-400 text-sm border-2 border-dashed border-gray-100 rounded-2xl italic">User directory services managed by System Root</p>
                        </Card>
                    )}

                    {['notifications', 'units', 'docs', 'audit'].includes(activeTab) && (
                        <div className="py-20 flex flex-col items-center justify-center text-center space-y-4 opacity-30 select-none">
                            <Activity className="w-12 h-12" />
                            <p className="text-sm font-black uppercase tracking-widest">Module restricted to system administrators</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Settings;
