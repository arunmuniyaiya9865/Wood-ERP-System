import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchLogs, fetchLogStats } from '../features/logs/logsSlice';
import PageHeader from '../components/ui/PageHeader';
import StatGrid from '../components/ui/StatGrid';
import Card from '../components/ui/Card';
import DataTable from '../components/ui/DataTable';
import Badge from '../components/ui/Badge';
import Spinner from '../components/ui/Spinner';
import Modal from '../components/ui/Modal';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Plus, Download } from 'lucide-react';

const LogsRawMaterials = () => {

  const [activeTab, setActiveTab] = useState('logs');
  const dispatch = useDispatch();
  const { logs, stats, loading } = useSelector(state => state.logs);

  // 🔥 LOG STATE
  const [localLogs, setLocalLogs] = useState([]);
  const [showLogModal, setShowLogModal] = useState(false);

  const [form, setForm] = useState({
    logId: '',
    species: '',
    topDiameter: '',
    bottomDiameter: '',
    length: '',
    volume: '',
    location: '',
  });

  // 🔥 MATERIAL STATE
  const [localMaterials, setLocalMaterials] = useState([]);
  const [showMaterialModal, setShowMaterialModal] = useState(false);

  const [materialForm, setMaterialForm] = useState({
    name: '',
    qty: '',
    price: '',
    amount: '',
  });

  const COLORS = ['#111','#444','#777','#aaa','#ccc'];

  useEffect(() => {
    dispatch(fetchLogs());
    dispatch(fetchLogStats());
  }, [dispatch]);

  // 🔥 VOLUME CALC
  const calculateVolume = (t, b, l) => {
    if (!t || !b || !l) return '';
    const d1 = t / 100;
    const d2 = b / 100;
    const len = l / 100;
    return ((Math.PI * len * (d1*d1 + d2*d2 + d1*d2)) / 12).toFixed(3);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    const newForm = { ...form, [name]: value };

    if (['topDiameter','bottomDiameter','length'].includes(name)) {
      newForm.volume = calculateVolume(
        newForm.topDiameter,
        newForm.bottomDiameter,
        newForm.length
      );
    }

    setForm(newForm);
  };

  const handleSaveLog = () => {
    if (!form.logId || !form.species) return;

    const newLog = {
      ...form,
      diameter: form.topDiameter,
      length: form.length / 100,
      grade: 'A1',
      status: 'available'
    };

    setLocalLogs(prev => [...prev, newLog]);
    setShowLogModal(false);

    setForm({
      logId: '',
      species: '',
      topDiameter: '',
      bottomDiameter: '',
      length: '',
      volume: '',
      location: '',
    });
  };

  // 🔥 MATERIAL
  const handleMaterialChange = (e) => {
    const { name, value } = e.target;
    const newForm = { ...materialForm, [name]: value };

    if (name === 'qty' || name === 'price') {
      newForm.amount = (newForm.qty || 0) * (newForm.price || 0);
    }

    setMaterialForm(newForm);
  };

  const handleSaveMaterial = () => {
    if (!materialForm.name) return;

    const newMaterial = {
      id: Date.now(),
      ...materialForm
    };

    setLocalMaterials(prev => [...prev, newMaterial]);
    setShowMaterialModal(false);

    setMaterialForm({
      name: '',
      qty: '',
      price: '',
      amount: '',
    });
  };

  const speciesData = [...logs, ...localLogs].reduce((acc, log) => {
    const existing = acc.find(a => a.name === log.species);
    if (existing) existing.value += 1;
    else acc.push({ name: log.species, value: 1 });
    return acc;
  }, []);

  return (
    <div className="w-full">

      <PageHeader
        title="Raw Material Inventory"
        subtitle="Logs + Materials"
        actions={
          <>
            <button className="btn-glass  flex items-center gap-2">
              <Download size={16}/> Report
            </button>

            {activeTab === 'logs' ? (
              <button onClick={()=>setShowLogModal(true)} className="btn-gradient flex items-center gap-2">
                <Plus size={16}/> Register Arrival
              </button>
            ) : (
              <button onClick={()=>setShowMaterialModal(true)} className="btn-gradient flex items-center gap-2">
                <Plus size={16}/> Add Material
              </button>
            )}
          </>
        }
      />

      <StatGrid stats={[
        { label: 'Total Logs', value: stats.totalLogs || 0 },
        { label: 'Volume', value: `${(stats.totalVolume || 0).toFixed(2)} m³` },
      ]} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <div className="lg:col-span-2">
          <Card className="p-0">

            {/* TABS */}
            <div className="flex border-b px-4">
              <button onClick={()=>setActiveTab('logs')} className={activeTab==='logs' ? 'border-b-2 border-black px-4 py-3' : 'px-4 py-3'}>
                Wood Logs
              </button>
              <button onClick={()=>setActiveTab('raw')} className={activeTab==='raw' ? 'border-b-2 border-black px-4 py-3' : 'px-4 py-3'}>
                Raw Materials
              </button>
            </div>

            {loading ? <Spinner/> : activeTab === 'logs' ? (

              <DataTable
                headers={['Log ID','Species','Dimensions','Volume']}
                data={[...logs, ...localLogs]}
                renderRow={(log)=>(
                  <> 
                    <td className="px-5 py-4">{log.logId}</td>
                    <td className="px-5 py-4">{log.species}</td>
                    <td className="px-5 py-4">
                      {log.topDiameter}/{log.bottomDiameter} cm × {log.length} m
                    </td>
                    <td className="px-5 py-4">{log.volume} m³</td>
                  </>
                )}
              />

            ) : (

              <DataTable
                headers={['Name','Qty','Price','Amount']}
                data={localMaterials}
                renderRow={(m)=>(
                  <>
                    <td className="px-5 py-4">{m.name}</td>
                    <td className="px-5 py-4">{m.qty}</td>
                    <td className="px-5 py-4">₹{m.price}</td>
                    <td className="px-5 py-4">₹{m.amount}</td>
                  </>
                )}
              />

            )}

          </Card>
        </div>

        {/* PIE */}
        <div>
          <Card title="Species">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={speciesData} dataKey="value">
                  {speciesData.map((e,i)=>(
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>

      </div>

      {/* LOG MODAL */}
      <Modal isOpen={showLogModal} onClose={()=>setShowLogModal(false)} title="Add Log">
        <div className="space-y-3">
          <input name="logId" placeholder="Code" onChange={handleFormChange} className="input-glass"/>
          <input name="species" placeholder="Wood Name" onChange={handleFormChange} className="input-glass"/>
          <input name="topDiameter" placeholder="Top Dia" onChange={handleFormChange} className="input-glass"/>
          <input name="bottomDiameter" placeholder="Bottom Dia" onChange={handleFormChange} className="input-glass"/>
          <input name="length" placeholder="Length (cm)" onChange={handleFormChange} className="input-glass"/>
          <input value={form.volume} placeholder='Volume' readOnly className="input-glass bg-gray-100"/>
          <input name="location" placeholder="Location" onChange={handleFormChange} className="input-glass"/>

          <button onClick={handleSaveLog} className="btn-gradient w-full">Save</button>
        </div>
      </Modal>

      {/* MATERIAL MODAL */}
      <Modal isOpen={showMaterialModal} onClose={()=>setShowMaterialModal(false)} title="Add Material">
        <div className="space-y-3">
          <input name="name" placeholder="Material Name" onChange={handleMaterialChange} className="input-glass"/>
          <input name="qty" placeholder="Quantity" onChange={handleMaterialChange} className="input-glass"/>
          <input name="price" placeholder="Price" onChange={handleMaterialChange} className="input-glass"/>
          <input value={materialForm.amount} placeholder='Amount' readOnly className="input-glass bg-gray-100"/>

          <button onClick={handleSaveMaterial} className="btn-gradient w-full">Save</button>
        </div>
      </Modal>

    </div>
  );
};

export default LogsRawMaterials;