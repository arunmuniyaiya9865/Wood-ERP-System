import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchInvoices, fetchCashFlow, fetchFinanceStats } from '../features/finance/financeSlice';
import PageHeader from '../components/ui/PageHeader';
import StatGrid from '../components/ui/StatGrid';
import Card from '../components/ui/Card';
import DataTable from '../components/ui/DataTable';
import Badge from '../components/ui/Badge';
import Spinner from '../components/ui/Spinner';
import { formatCurrency, formatDate } from '../utils/formatters';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Download, CreditCard, Wallet, TrendingUp, Filter } from 'lucide-react';

const Finance = () => {
    const dispatch = useDispatch();
    const { invoices, cashFlow, stats, loading } = useSelector(state => state.finance);

    useEffect(() => {
        dispatch(fetchInvoices());
        dispatch(fetchCashFlow());
        dispatch(fetchFinanceStats());
    }, [dispatch]);

    const statItems = [
        { label: 'YTD Revenue', value: formatCurrency(stats.ytdRevenue || 0), trend: 18.5 },
        { label: 'Net Profit', value: formatCurrency(stats.netProfit || 0), sub: 'Post-operational deduction' },
        { label: 'Outstanding A/R', value: formatCurrency(stats.outstandingAR || 0), trend: -5.2, sub: 'Active receivables' },
        { label: 'Cash Position', value: formatCurrency(stats.cashPosition || 0), sub: 'Liquid capital availability' },
    ];

    return (
        <div>
            <PageHeader 
                title="Financial Terminal" 
                subtitle="Centralized management of accounts receivable, invoicing, and corporate cash flow"
                actions={
                    <>
                        <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-semibold hover:bg-gray-50 transition-colors shadow-sm">
                            <Download className="w-4 h-4 text-gray-400" />
                            Financial Report
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm font-semibold hover:bg-gray-800 transition-all shadow-sm">
                            <CreditCard className="w-4 h-4" />
                            Record Payment
                        </button>
                    </>
                }
            />

            <StatGrid stats={statItems} />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
                {/* Cashflow Chart */}
                <div className="lg:col-span-1">
                    <Card title="Cash Flow Projection" subtitle="Monthly inflows vs operational outflows">
                        <div className="h-[300px] mt-6">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={cashFlow} margin={{ top: 5, right: 0, left: -20, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: '700', fill: '#9CA3AF' }} />
                                    <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#9CA3AF' }} />
                                    <Tooltip 
                                        cursor={{ fill: '#F9FAFB' }}
                                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                                    />
                                    <Bar dataKey="inflow" fill="#111111" radius={[4, 4, 0, 0]} name="Inflow" />
                                    <Bar dataKey="outflow" fill="#D1D5DB" radius={[4, 4, 0, 0]} name="Outflow" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="mt-8 flex justify-between px-4">
                            <div className="text-center">
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Burn Rate</p>
                                <p className="text-sm font-black text-gray-900">$34.5k</p>
                            </div>
                            <div className="text-center">
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Runway</p>
                                <p className="text-sm font-black text-gray-900">14.2 Mo</p>
                            </div>
                            <div className="text-center">
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">EBITDA</p>
                                <p className="text-sm font-black text-green-700">+12%</p>
                            </div>
                        </div>
                    </Card>
                </div>

                {/* Invoices List */}
                <div className="lg:col-span-2">
                    <Card className="p-0 overflow-hidden">
                        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
                            <h3 className="text-[11px] font-extrabold text-gray-400 uppercase tracking-widest">Active Accounts Receivable</h3>
                            <Filter className="w-4 h-4 text-gray-400" />
                        </div>
                        <DataTable 
                            headers={['Invoice ID', 'Customer Entity', 'Billed Amount', 'Issued Date', 'Due Date', 'Settlement Status']}
                            data={invoices}
                            renderRow={(inv) => (
                                <>
                                    <td className="px-5 py-4 text-[13px] font-bold text-gray-900">{inv.invoiceId}</td>
                                    <td className="px-5 py-4 text-[13px] font-bold text-gray-700">{inv.customer?.name}</td>
                                    <td className="px-5 py-4 text-[13px] font-black text-gray-900">{formatCurrency(inv.amount)}</td>
                                    <td className="px-5 py-4 text-[13px] text-gray-600 font-medium">{formatDate(inv.issuedDate)}</td>
                                    <td className="px-5 py-4 text-[13px] text-red-500 font-bold">{formatDate(inv.dueDate)}</td>
                                    <td className="px-5 py-4 text-[13px]"><Badge status={inv.status} /></td>
                                </>
                            )}
                        />
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default Finance;
